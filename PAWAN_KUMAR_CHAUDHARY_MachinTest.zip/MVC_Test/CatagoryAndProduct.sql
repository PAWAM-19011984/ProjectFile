Create table tblCatagory
(
  CategoryID int primary key identity(1000,1),
  CategoryName nvarchar(100)  
)
GO
select * from tblCatagory
GO
Create table tblProduct
(
  ProductID int primary key identity(100,1),
  ProductName nvarchar(100),
  CategoryID int foreign key references tblCatagory(CategoryID)
)
GO
select * from tblProduct
GO
CREATE Procedure spUpdateCatagory
  @CategoryID nvarchar(10),
  @CategoryName nvarchar(100)
As
Begin
	update tblCatagory set CategoryName = @CategoryName where CategoryID = @CategoryID
End
GO
CREATE Procedure spUpdatetblProduct
  @CategoryID nvarchar(10),
  @ProductID nvarchar(10),
  @CategoryName nvarchar(100)
As
Begin
	update tblProduct set ProductName = @CategoryName, CategoryID = @CategoryID where ProductID = @ProductID
End
GO
CREATE Procedure spDeleteCatagory
  @CategoryID nvarchar(10)
As
Begin
	delete from tblCatagory where CategoryID = @CategoryID
End
GO
CREATE Procedure spDeleteProduct
  @ProductID nvarchar(10)
As
Begin
	delete from tblProduct  where ProductID = @ProductID
End



