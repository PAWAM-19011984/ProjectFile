﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;
using MVC_Test.Models;
using System.Data;

namespace MVC_Test.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(int? page)
        {
            CategoryProductEntities dbConnection = new CategoryProductEntities();
            return View(dbConnection.Catagories.ToList().ToPagedList((page ?? 1),10));
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create_Get()
        {
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create_Post(Catagory catagory)
        {
            if (ModelState.IsValid)
            {
                CategoryProductEntities dbConnection = new CategoryProductEntities();
                dbConnection.Catagories.AddObject(catagory);
                dbConnection.SaveChanges();
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        [ActionName("Edit")]
        public ActionResult Edit(int id)
        {
            CategoryProductEntities dbConnection = new CategoryProductEntities();
            Catagory catagory = dbConnection.Catagories.Single(c => c.CategoryID==id);
            return View(catagory);
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit_Post(Catagory catagory)
        {
            if (ModelState.IsValid)
            {
                BusinessLayer businessLayer = new BusinessLayer();
                businessLayer.UpdateCatagory(catagory);
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        [ActionName("Delete")]
        public ActionResult Delete_Get(int id)
        {
            CategoryProductEntities dbConnection = new CategoryProductEntities();
            Catagory catagory = dbConnection.Catagories.Single(c => c.CategoryID == id);
            return View(catagory);
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult Delete_Post(Catagory catagory)
        {
            BusinessLayer businessLayer = new BusinessLayer();
            businessLayer.DeleteCatagory(catagory);
            return RedirectToAction("Index");

        }
    }
}
