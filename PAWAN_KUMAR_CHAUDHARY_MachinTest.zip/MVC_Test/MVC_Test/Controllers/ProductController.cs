﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using PagedList.Mvc;
using MVC_Test.Models;
using System.Data;


namespace MVC_Test.Controllers
{
    public class ProductController : Controller
    {
        public ActionResult Index(int? page)
        {
            CategoryProductEntities dbConnection = new CategoryProductEntities();
            return View(dbConnection.Products.Include("tblCatagory").ToList().ToPagedList((page ?? 1), 10));
        }

        [HttpGet]
        [ActionName("Create")]
        public ActionResult Create_Get()
        {
            CategoryProductEntities dbConnection = new CategoryProductEntities();
            ViewBag.CategoryID = new SelectList(dbConnection.Catagories, "CategoryID", "CategoryName");
            return View();
        }

        [HttpPost]
        [ActionName("Create")]
        public ActionResult Create_Post(Product product)
        {
            if (ModelState.IsValid && product.CategoryID != null)
            {
                CategoryProductEntities dbConnection = new CategoryProductEntities();
                dbConnection.Products.AddObject(product);
                dbConnection.SaveChanges();
                return RedirectToAction("Index");
            }
            if (product.CategoryID == null)
            {
                ModelState.AddModelError("1", "Please Select Product.");
                CategoryProductEntities dbConnection = new CategoryProductEntities();
                return View("Index", dbConnection.Products.Include("tblCatagory").ToList().ToPagedList((1), 10));
            }
            return View();
        }

        [HttpGet]
        [ActionName("Edit")]
        public ActionResult Edit_Get(int id)
        {
            CategoryProductEntities dbConnection = new CategoryProductEntities();
            ViewBag.CategoryID = new SelectList(dbConnection.Catagories, "CategoryID", "CategoryName", new { selectedValue = id });
            Product product = dbConnection.Products.Single(c => c.ProductID == id);
            return View(product);
        }

        [HttpPost]
        [ActionName("Edit")]
        public ActionResult Edit_Post(Product product)
        {
            if (ModelState.IsValid && product.CategoryID != null)
            {
                BusinessLayer businessLayer = new BusinessLayer();
                businessLayer.UpdateProduct(product);
                return RedirectToAction("Index");
            }
            if (product.CategoryID == null)
            {
                ModelState.AddModelError("1", "Please Select Product.");
                CategoryProductEntities dbConnection = new CategoryProductEntities();
                return View("Index", dbConnection.Products.Include("tblCatagory").ToList().ToPagedList((1), 10));
            }
            return View();
        }

        [HttpGet]
        [ActionName("Delete")]
        public ActionResult Delete_Get(int id)
        {
            CategoryProductEntities dbConnection = new CategoryProductEntities();
            Product product = dbConnection.Products.Single(c => c.ProductID == id);
            return View(product);
        }

        [HttpPost]
        [ActionName("Delete")]
        public ActionResult Delete_Post(Product product)
        {
            BusinessLayer businessLayer = new BusinessLayer();
            businessLayer.DeleteProduct(product);
            return RedirectToAction("Index");

        }
    }
}
