﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace MVC_Test.Models
{
    public class BusinessLayer
    {
        public void UpdateCatagory(Catagory catagory)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
            using(SqlConnection cnn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spUpdateCatagory", cnn);
                cmd.CommandType = CommandType.StoredProcedure;
               
                SqlParameter CategoryID = new SqlParameter();
                CategoryID.Value = catagory.CategoryID;
                CategoryID.ParameterName = "@CategoryID";
                cmd.Parameters.Add(CategoryID);

                SqlParameter CategoryName = new SqlParameter();
                CategoryName.Value = catagory.CategoryName;
                CategoryName.ParameterName = "@CategoryName";
                cmd.Parameters.Add(CategoryName);
                cnn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateProduct(Product product)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spUpdatetblProduct", cnn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter CategoryID = new SqlParameter();
                CategoryID.Value = product.CategoryID;
                CategoryID.ParameterName = "@CategoryID";
                cmd.Parameters.Add(CategoryID);

                SqlParameter ProductID = new SqlParameter();
                ProductID.Value = product.ProductID;
                ProductID.ParameterName = "@ProductID";
                cmd.Parameters.Add(ProductID);

                SqlParameter CategoryName = new SqlParameter();
                CategoryName.Value = product.ProductName;
                CategoryName.ParameterName = "@CategoryName";
                cmd.Parameters.Add(CategoryName);
                cnn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteCatagory(Catagory catagory)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spDeleteCatagory", cnn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter CategoryID = new SqlParameter();
                CategoryID.Value = catagory.CategoryID;
                CategoryID.ParameterName = "@CategoryID";
                cmd.Parameters.Add(CategoryID);

                cnn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteProduct(Product product)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["connectionString"].ConnectionString;
            using (SqlConnection cnn = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spDeleteProduct", cnn);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter ProductID = new SqlParameter();
                ProductID.Value = product.ProductID;
                ProductID.ParameterName = "@ProductID";
                cmd.Parameters.Add(ProductID);

                cnn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}