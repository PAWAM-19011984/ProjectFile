﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;

namespace MVC_Test.Models
{
    
    public partial class Catagory
    {
        //public partial int CategoryID { get; set; }
        //[Required]
        //public partial string CategoryName { get; set; }

    }

}